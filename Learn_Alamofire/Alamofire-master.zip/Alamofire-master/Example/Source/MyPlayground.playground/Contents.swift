//: Playground - noun: a place where people can play

import UIKit
/**
枚举嵌套枚举
结构体嵌套枚举
枚举设置类型
枚举值关联
枚举中定义函数
枚举中定义属性
*/

enum House: String {
    case ZhangSan = "I am zhangsan"
    case LiSi = "I am lisi"
}

let zs = House.ZhangSan
print(zs.rawValue)


enum CompassPoint: String {
    case North, South, East, West
}

let n = CompassPoint.North
print(n.rawValue)

let s = CompassPoint(rawValue: "South");



enum Movement {
    case Left
    case Right
    case Top
    case Bottom
}

let aMovement = Movement.Left

switch aMovement {
case .Left:
    print("left")
default:
    print("Unknow")
}

if case .Left = aMovement {
    print("Left")
}

if .Left == aMovement {
    print("Left")
}

