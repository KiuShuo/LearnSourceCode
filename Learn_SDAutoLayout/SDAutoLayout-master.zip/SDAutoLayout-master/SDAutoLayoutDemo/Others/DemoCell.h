//
//  DemoCell.h
//  SDAutoLayout 测试 Demo
//
//  Created by gsd on 16/1/8.
//  Copyright © 2016年 gsd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoCell : UITableViewCell

@property (nonatomic, weak) UILabel *titleLabel;
@property (nonatomic, weak) UILabel *contentLabel;

@end
