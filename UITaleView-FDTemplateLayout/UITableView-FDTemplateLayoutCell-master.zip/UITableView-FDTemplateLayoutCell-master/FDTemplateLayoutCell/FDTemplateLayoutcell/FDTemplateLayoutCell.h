//
//  FDTemplateLayoutCell.h
//  FDTemplateLayoutCell
//
//  Created by ospreyren on 9/19/15.
//
//

#import <UIKit/UIKit.h>

//! Project version number for FDTemplateLayoutCell.
FOUNDATION_EXPORT double FDTemplateLayoutCellVersionNumber;

//! Project version string for FDTemplateLayoutCell.
FOUNDATION_EXPORT const unsigned char FDTemplateLayoutCellVersionString[];

#import <FDTemplateLayoutCell/UITableView+FDTemplateLayoutCell.h>
