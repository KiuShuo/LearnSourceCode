//
//  C1.m
//  CellHigthDemo
//
//  Created by Haven on 19/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import "C1.h"
#import "NSLayoutConstraint+ClassMethodPriority.h"

@implementation C1


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
