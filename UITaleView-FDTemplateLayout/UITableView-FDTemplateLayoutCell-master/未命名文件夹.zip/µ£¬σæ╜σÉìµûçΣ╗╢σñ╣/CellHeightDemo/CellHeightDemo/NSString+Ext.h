//
//  NSString+Ext.h
//  v2ex
//
//  Created by Haven on 18/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Ext)
- (CGSize)calculateSize:(CGSize)size font:(UIFont *)font;
@end
