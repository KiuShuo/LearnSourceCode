//
//  T2ViewController.h
//  CellHeightDemo
//
//  Created by Haven on 20/2/14.
//  Copyright (c) 2014 LF. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface T2ViewController : BaseViewController

@end
