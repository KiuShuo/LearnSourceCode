//
//  MJRefreshStateHeader+RefreshHeaderTimer.m
//  MJRefreshExample
//
//  Created by shuo on 2017/10/30.
//  Copyright © 2017年 小码哥. All rights reserved.
//

#import "MJRefreshStateHeader+RefreshHeaderTimer.h"

@implementation MJRefreshStateHeader (RefreshHeaderTimer)

- (void)didMoveToSuperview {
    [super didMoveToSuperview];
    self.lastUpdatedTimeLabel.hidden = YES;
}

@end
