//
//  MJRefreshStateHeader+RefreshHeaderTimer.h
//  MJRefreshExample
//
//  Created by shuo on 2017/10/30.
//  Copyright © 2017年 小码哥. All rights reserved.
//

#import "MJRefreshStateHeader.h"

@interface MJRefreshStateHeader (RefreshHeaderTimer)

@end
