//
//  MJChiBaoZiHeader.h
//  MJRefreshExample
//
//  Created by MJ Lee on 15/6/12.
//  Copyright © 2015年 小码哥. All rights reserved.
//  吃包子效果的头部控件

#import "MJRefreshGifHeader.h"

@interface MJChiBaoZiHeader : MJRefreshGifHeader

@end
